
<?php $__env->startSection('css'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.bootstrap5.min.css">

    <style>
        .toast-success{
            background-color: #51a351 !important;
        }
        .toast-error{
            background-color: #be5252 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Lista de adquisiciones almacen</h4>
                    <?php if(Auth::user()->categoria == 'cap'): ?>
                        <div class="row">
                            <div class="col align-self-end text-end">
                                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#agregar">Agregar Adquision</button>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="container border">
                        <h5 class="text-center mt-2">Adquisiciones adjudicadas al proveedor</h5>
                        <table id="example" class="table table-striped dt-responsive nowrap border" style="width:100%;">
                            <thead>
                                <tr>
                                    <th>Fecha Ingreso</th>
                                    <th>Folio</th>
                                    <th>Dependencia</th>
                                    <th>Contenido</th>
                                    <th>Observaciones</th>
                                    <th>Documentación</th>
                                    <th>Estatus</th>
                                    <th>Partida Presupuestal</th>
                                    <th>Descripción General</th>
                                    <th>Clasificación</th>
                                    <th>Unidad de Medida</th>
                                    <th>Desc. Adquisición</th>
                                    <th>Fuentes de Financiamiento</th>
                                    <th>Monto</th>
                                    <th>Proveedor</th>
                                    <th>Fecha de Adjudicación</th>
                                    <th>Fecha Entrega</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $adquisiciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adquisicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr 
                                <?php if(Auth::user()->categoria <> 'admin' && Auth::user()->categoria <> 'cap'): ?>
                                    <?php if($adquisicion->adquisicion_estatus == 2): ?>
                                        style = "color:black;background:#7BCB62;"
                                    <?php elseif($adquisicion->adquisicion_estatus == 1): ?>
                                        style = "color:black;background:#FFFFFF;"
                                    <?php elseif($adquisicion->adquisicion_estatus == 0): ?>
                                        style = "color:black;background:#CB6262;"
                                    <?php endif; ?>  
                                <?php endif; ?>
                                >
                                    <td><?php echo e($adquisicion->fechaadqui); ?></td>
                                    <td><?php echo e($adquisicion->folio); ?></td>
                                    <td><?php echo e($adquisicion->dependencia_nombre); ?></td>
                                    <td>
                                        <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#contenido<?php echo e($adquisicion->idadquisicion); ?>"><i class="fa-regular fa-folder-closed"></i> Contenido</button>
                                    </td>
                                    <td>
                                        <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#observaciones<?php echo e($adquisicion->idadquisicion); ?>"><i class="fa-regular fa-eye"></i> Observaciones</button>
                                    </td>
                                    <td>
                                        <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#documentacion<?php echo e($adquisicion->idadquisicion); ?>"><i class="fa-regular fa-file"></i> Documentos</button>
                                    </td>
                                    <td>
                                        <?php if($adquisicion->adquisicion_estatus == 4): ?>
                                            A LA ESPERA DEL PROVEEDOR
                                        <?php elseif($adquisicion->adquisicion_estatus == 5): ?>
                                            EN EL ALMANCEN
                                        <?php elseif($adquisicion->adquisicion_estatus == 6): ?>
                                            ENTREGADO
                                        <?php else: ?>
                                            ERROR
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($adquisicion->partida ?? 'No se agrego partida presupuestal'); ?></td>
                                    <td><?php echo e($adquisicion->descripcion); ?></td>
                                    <td><?php echo e($adquisicion->clasificacion_nombre); ?></td>
                                    <td><?php echo e($adquisicion->medida_nombre); ?></td>
                                    <td><?php echo e($adquisicion->descripcionadqui); ?></td>
                                    <td><?php echo e($adquisicion->financiamiento_nombre); ?></td>
                                    <td>$<?php echo e(number_format($adquisicion->monto,2, '.', ',')); ?></td>
                                    <td><?php echo e($adquisicion->nombre_comercial ?? 'No hay proveedor'); ?></td>
                                    <td><?php echo e($adquisicion->fechaaprox); ?></td>
                                    <td><?php echo e($adquisicion->fechaentrega); ?></td>
                                    <td>
                                        <?php if($adquisicion->adquisicion_estatus == 4): ?>
                                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editar<?php echo e($adquisicion->idadquisicion); ?>">Editar</button>    
                                        <?php else: ?>
                                            NO ACCIONES QUE REALIZAR
                                        <?php endif; ?>
                                        
                                    </td>
                                </tr>
                                <?php echo $__env->make('adquisiciones.modales.modaleditaralmacen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('adquisiciones.modales.modalobservaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('adquisiciones.modales.modaldocumentacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('adquisiciones.modales.modalcontenido', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>
    <script>
        $(document).ready(function() {
            toastr.options.timeOut = 8000;
            <?php if(Session::has('error')): ?>
                toastr.error('<?php echo e(Session::get('error')); ?>');
            <?php elseif(Session::has('success')): ?>
                toastr.success('<?php echo e(Session::get('success')); ?>');
            <?php endif; ?>
        });
    </script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/responsive.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                scrollX: true,
                "lengthMenu": [[15,20,50,-1],[15,20,50,"Todos"]],
                language: {
                    "decimal": "",
                    "emptyTable": "No hay información",
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                    "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                    "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "Mostrar _MENU_ Registros",
                    "loadingRecords": "Cargando...",
                    "processing": "Procesando...",
                    "search": "Buscar:",
                    "zeroRecords": "Sin resultados encontrados",
                    "paginate": {
                        "first": "Primero",
                        "last": "Ultimo",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                },
            });
        });
    </script>
    
<?php $__env->stopSection(); ?>
<!-- Modal -->
    <div class="modal fade" id="agregar" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Agregar adquisición</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form action="<?php echo e(route('agregaradquisicion')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-3">
                        <label for="" class="form-lable">Fecha de ingreso</label>
                        <input type="text" name="fingreso" id="fingreso" class="form-control <?php $__errorArgs = ['fingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($fecha); ?>" readonly>
                    </div>
                    <div class="col-3">
                        <label for="" class="form-lable">Folio</label>
                        <input type="text" name="folio" id="folio" minlength="5" maxlength="5" pattern="[0-9]{5,5}" class="form-control <?php $__errorArgs = ['folio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('folio')); ?>" required>
                    </div>
                    <div class="col-6"> 
                        <label for="" class="form-lable">Unidad presupuestaria responsable</label>
                        <select name="dependencia" id="dependencia" class="form-select <?php $__errorArgs = ['dependencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="" selected>Seleccionar presupuestaria responsable...</option>
                            <?php $__currentLoopData = $dependencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dependencia->iddependencia); ?>"><?php echo e($dependencia->dependencia_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6 mt-2">
                        <label for="" class="form-lable">Documento presentado</label>
                        <input type="file" name="dpresentado" id="dpresentado" accept=".pdf" class="form-control <?php $__errorArgs = ['dpresentado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['dpresentado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6 mt-2">
                        <label for="" class="form-lable">Investigación de mercado</label>
                        <input type="file" name="imercado" id="imercado" accept=".pdf" class="form-control <?php $__errorArgs = ['imercado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-6 mt-2">
                        <label for="" class="form-lable">Respuesta requisitoria</label>
                        <input type="file" name="rrequisitoria" id="rrequisitoria" accept=".pdf" class="form-control <?php $__errorArgs = ['rrequisitoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                    <div class="col-6 mt-2">
                        <label for="" class="form-lable">Partida presupuestal</label>
                        <input type="text" name="ppresupuestal" id="ppresupuestal" class="form-control <?php $__errorArgs = ['ppresupuestal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4 mt-2">
                        <label for="" class="form-lable">Clasificaciones</label>
                        <select name="clasificacion" id="clasificacion" class="form-select <?php $__errorArgs = ['clasificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="" selected>Seleccionar clasificacion...</option>
                            <?php $__currentLoopData = $clasificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($clasificacion->idclasificacion); ?>"><?php echo e($clasificacion->clasificacion_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-4 mt-2">
                        <label for="" class="form-lable">Unidad de medida</label>
                        <select name="umedida" id="umedida" class="form-select <?php $__errorArgs = ['umedida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="" selected>Seleccionar unidad de medida...</option>
                            <?php $__currentLoopData = $medidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($medida->idmedida); ?>"><?php echo e($medida->medida_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-4 mt-2">
                        <label for="" class="form-lable">Fuentes de financiamiento</label>
                        <select name="ffinanciamiento" id="ffinanciamiento" class="form-select <?php $__errorArgs = ['ffinanciamiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="" selected>Seleccionar fuente de financiamiento...</option>
                            <?php $__currentLoopData = $financiamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $financiamiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($financiamiento->idfinanciamiento); ?>"><?php echo e($financiamiento->financiamiento_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-3 mt-2">
                        <label for="" class="form-lable">Monto $</label>
                        <input type="number" name="monto" id="monto" class="form-control <?php $__errorArgs = ['monto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" step="0.01">
                    </div>
                    <div class="col-3 mt-2">
                        <label for="" class="form-lable">Proveedor</label>
                        <input type="text" name="proveedor" id="proveedor" class="form-control <?php $__errorArgs = ['proveedor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                    <div class="col-3 mt-2">
                        <label for="" class="form-lable">Fecha de adjudicación</label>
                        <input type="date" name="faprox" id="faprox" class="form-control <?php $__errorArgs = ['faprox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                    <div class="col-3 mt-2">
                        <label for="" class="form-lable">Fecha de entrega</label>
                        <input type="date" name="fentrega" id="fentrega" class="form-control <?php $__errorArgs = ['fentrega'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4 mt-2">
                        <label for="" class="form-lable">Descripción general de bienes</label>
                        <textarea name="dgeneral" id="dgeneral" cols="45" rows="5" class="form-control <?php $__errorArgs = ['dgeneral'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="resize: none;"></textarea>
                    </div>
                    <div class="col-4 mt-2">
                        <label for="" class="form-lable">Descripción de la adquisición</label>
                        <textarea name="dadquisicion" id="dadquisicion" cols="45" rows="5" class="form-control <?php $__errorArgs = ['dadquisicion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="resize: none;"></textarea>
                    </div>
                    <div class="col-4 mt-2">
                        <label for="" class="form-lable">Observaciones</label>
                        <textarea name="observaciones" id="observaciones" cols="45" rows="5" class="form-control <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="resize: none;"></textarea>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary mt-2" onclick="return confirm('¿Desea guardar esta nueva adquisición?')">Guardar</button>
            </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\charr\Documents\proyectos\compras\resources\views/adquisiciones/indexalmacen.blade.php ENDPATH**/ ?>