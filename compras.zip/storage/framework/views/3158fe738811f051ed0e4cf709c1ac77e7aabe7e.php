<div class="sidebar close wrapper" id="side_nav">
    <div class="logo-details">
        <i class="fa-solid fa-o"></i>
        <span class="logo_name">SIA</span>
    </div>
    <?php if(Auth::user()->user_estatus == 1): ?>
    <ul class="nav-links">
        <li>
            <a href="<?php echo e(route('home')); ?>">
            <i class='bx bx-grid-alt' ></i>
            <span class="link_name">Formatos</span>
            </a>
            <ul class="sub-menu blank">
            <li><a class="link_name" href="<?php echo e(route('home')); ?>">Inicio</a></li>
            </ul>
        </li>
        <?php if(Auth::user()->categoria == 'admin' || Auth::user()->categoria == 'compras'): ?>
        <li>
            <div class="iocn-link">
            <a href="#">
                <i class='bx bx-collection' ></i>
                <span class="link_name">Catálogos</span>
            </a>
            <i class='bx bxs-chevron-down arrow' ></i>
            </div>
            <ul class="sub-menu">
                <li><a href="<?php echo e(route('indice')); ?>">Clasificaciones</a></li>
                <li><a href="<?php echo e(route('indicemedida')); ?>">Unidades de medida</a></li>
                
                <li><a href="<?php echo e(route('indicedependencia')); ?>">Dependencias</a></li>
                <li><a href="<?php echo e(route('indiceproveedor')); ?>">Proveedores</a></li>
            </ul>
        </li>
        <?php endif; ?>
        <li>
            <div class="iocn-link">
            <?php if(Auth::user()->categoria <> 'admin' && Auth::user()->categoria <> 'compras' && Auth::user()->categoria <> 'almacen'): ?>
                <a href="<?php echo e(route('indiceadquisiciones')); ?>">
            <?php else: ?>
            <a href="#">
            <?php endif; ?>
                
                <i class="fa-regular fa-note-sticky"></i>
                <span class="link_name">Adquisiciones</span>
            </a>
            <?php if(Auth::user()->categoria == 'admin'|| Auth::user()->categoria == 'compras' || Auth::user()->categoria == 'almacen'): ?>
                <i class='bx bxs-chevron-down arrow'></i>
            <?php endif; ?>
            </div>
            
            <?php if(Auth::user()->categoria == 'admin' || Auth::user()->categoria == 'compras'): ?>
            <ul class="sub-menu">
                <li><a href="<?php echo e(route('indiceadquisiciones')); ?>">Recibidas</a></li>
                <li><a href="<?php echo e(route('indexaceptadas')); ?>">Recepcion aceptadas</a></li>
                <li><a href="<?php echo e(route('indexaprobadas')); ?>">Autorizadas</a></li>
                <li><a href="<?php echo e(route('indexrechazadas')); ?>">Rechazadas</a></li>
                
                <li><a href="<?php echo e(route('almacenespera')); ?>">Adjudicadas</a></li>
                <li><a href="<?php echo e(route('enalmacen')); ?>">En almancen</a></li>
                <li><a href="<?php echo e(route('almancenentregada')); ?>">Entregadas</a></li>
            </ul>            
            <?php elseif( Auth::user()->categoria == 'almacen'): ?>
            <ul class="sub-menu">    
                <li><a href="<?php echo e(route('almacenespera')); ?>">Adjudicadas</a></li>
                <li><a href="<?php echo e(route('enalmacen')); ?>">En almancen</a></li>
                <li><a href="<?php echo e(route('almancenentregada')); ?>">Entregadas</a></li>
            </ul>
            <?php endif; ?>
        </li>
        <?php if(Auth::user()->categoria == 'admin'): ?>
            <li>
                <a href="<?php echo e(route('indiceusuario')); ?>">
                
                <i class="fa-regular fa-user"></i>
                <span class="link_name">Usuarios</span>
                </a>
                <ul class="sub-menu blank">
                <li><a class="link_name" href="<?php echo e(route('indiceusuario')); ?>">Usuarios</a></li>
                </ul>
            </li>
        <?php endif; ?>
        <?php if(Auth::user()->categoria == 'admin' || Auth::user()->categoria == 'compras'): ?>
            <li>
                <a href="<?php echo e(route('indicemov')); ?>">
                
                <i class="fa-regular fa-chart-bar"></i>
                <span class="link_name">Movimientos</span>
                </a>
                <ul class="sub-menu blank">
                <li><a class="link_name" href="<?php echo e(route('indicemov')); ?>">Movimientos</a></li>
                </ul>
            </li>   
        <?php endif; ?>
        
        
        
            
            <!--<li>
                <a href="#">
                <i class='bx bx-history'></i>
                <span class="link_name">Historial</span>
                </a>
                <ul class="sub-menu blank">
                <li><a class="link_name" href="#">Historial</a></li>
                </ul>
            </li>-->
            
       
    </ul>
    <?php else: ?>
    <ul class="nav-links">
        <li>
            <p>Usuario dado de baja</p>
        </li>
    </ul>
    <?php endif; ?>
</div><?php /**PATH C:\Users\charr\Documents\proyectos\compras\resources\views/layouts/menusidebar.blade.php ENDPATH**/ ?>