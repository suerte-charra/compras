
<!-- Modal -->
<div class="modal fade" id="editar<?php echo e($adquisicion->idadquisicion); ?>" data-bs-backdrop="static" data-bs-keyboard="false"  aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Editar Adquisición: <?php echo e($adquisicion->idadquisicion); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form action="<?php echo e(route('actualizaradquisicion',$adquisicion->idadquisicion)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-3">
                        <label for="" class="form-label">Fecha de ingreso</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['fingresio_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($adquisicion->fechaadqui); ?>" id="fingresio_1" name="fingresio_1" readonly>
                    </div>
                    <div class="col-md-3">
                        <label for="" class="form-label">Folio</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['folio_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($adquisicion->folio); ?>" id="folio_1" name="folio_1" readonly>
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Unidad presupuestaria responsable</label>
                        <input type="text" name="nactual" id="nactual" class="form-control" value="<?php echo e($adquisicion->dependencia_nombre); ?>" readonly>
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mt-2 border">
                        <label for="" class="form-label">Requisición digitalizada</label>
                        <?php if($adquisicion->documento): ?>
                            <a href="<?php echo e(asset('/documentos/documentospresentados/'.$adquisicion->documento)); ?>" target="_blank"><?php echo e($adquisicion->documento); ?></a>
                        <?php else: ?>
                            No tiene documento
                        <?php endif; ?>
                        <input type="file" name="dpresentado_1" id="dpresentado_1" accept=".pdf" class="form-control <?php $__errorArgs = ['dpresentado_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                    <div class="col-md-6 mt-2 border">
                        <label for="" class="form-label">Investigación de mercado&nbsp;</label>
                        <?php if($adquisicion->investigacion): ?>
                            <a href="<?php echo e(asset('/documentos/investigaciondemercado/'.$adquisicion->investigacion)); ?>" target="_blank"><?php echo e($adquisicion->investigacion); ?></a>
                        <?php else: ?>
                            No tiene investigación de mercado
                        <?php endif; ?>
                        <input type="file" name="imercado_1" id="imercado_1" accept=".pdf" class="form-control <?php $__errorArgs = ['imercado_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mt-2 border">
                        <label for="" class="form-label" title="Documento que avala si es aceptada o no">Respuesta requisitoria</label>
                        <?php if($adquisicion->resrequi): ?>
                            <a href="<?php echo e(asset('/documentos/respuestarequisitoria/'.$adquisicion->resrequi)); ?>" target="_blank"><?php echo e($adquisicion->resrequi); ?></a>
                        <?php else: ?>
                            No tiene respuesta requisitoria
                        <?php endif; ?>
                        <input type="file" name="rrequisitoria_1" id="rrequisitoria_1" accept=".pdf" class="form-control <?php $__errorArgs = ['rrequisitoria_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                    <div class="col-md-6 mt-2">
                        <label for="" class="form-label">Partida presupuestal</label>
                        <input type="text" name="ppresupuestal_1" id="ppresupuestal_1" class="form-control <?php $__errorArgs = ['ppresupuestal_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($adquisicion->partida); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mt-2 border">
                        <label for="" class="form-label">Clasificaciones</label>
                        <input type="text" name="nactual" id="nactual" class="form-control" value="<?php echo e($adquisicion->clasificacion_nombre); ?>" readonly>
                        <select name="clasificacion_1" id="clasificacion_1" class="form-select <?php $__errorArgs = ['clasificacion_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Si desea cambiar seleccione una opción</option>
                            <?php $__currentLoopData = $clasificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($adquisicion->clasificacion_nombre <> $clasificacion->clasificacion_nombre): ?>
                                    <option value="<?php echo e($clasificacion->idclasificacion); ?>"><?php echo e($clasificacion->clasificacion_nombre); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6 mt-2 border">
                        <label for="" class="form-label">Unidad de medida</label>
                        <input type="text" name="nactual" id="nactual" class="form-control" value="<?php echo e($adquisicion->medida_nombre); ?>" readonly>
                        <select name="umedida_1" id="umedida_1" class="form-select <?php $__errorArgs = ['umedida_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Si desea cambiar seleccione una opción</option>
                            <?php $__currentLoopData = $medidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($adquisicion->medida_nombre <> $medida->medida_nombre): ?>
                                    <option value="<?php echo e($medida->idmedida); ?>"><?php echo e($medida->medida_nombre); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-9 mt-2">
                        <label for="" class="form-lable">Proveedores</label>
                        <input list="proveedores" id="proveedor_1" name="proveedor_1" class="form-control" value="<?php echo e($adquisicion->idproveedor.'-'.$adquisicion->nombre_comercial ?? ''); ?>">
                        <datalist id="proveedores">
                            <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($proveedor->idproveedor); ?>-<?php echo e($proveedor->nombre_comercial); ?>"></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    </div>
                    <div class="col-3 mt-2">
                        <label for="" class="form-lable">Monto $</label>
                        <input type="text" name="monto_1" id="monto_1" class="form-control <?php $__errorArgs = ['monto_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($adquisicion->monto); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-6 mt-2">
                        <label for="" class="form-lable">Fecha de adjudicación</label>
                        <input type="date" name="faprox_1" id="faprox_1" class="form-control <?php $__errorArgs = ['faprox_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($adquisicion->fechaaprox); ?>">
                    </div>
                    <div class="col-6 mt-2">
                        <label for="" class="form-lable">Fecha de entrega</label>
                        <input type="date" name="fentrega_1" id="fentrega_1" class="form-control <?php $__errorArgs = ['fentrega_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($adquisicion->fechaentrega); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4 mt-2">
                        <label for="" class="form-lable">Descripción general de bienes</label>
                        <textarea name="dgeneral_1" id="dgeneral_1" cols="45" rows="5" class="form-control <?php $__errorArgs = ['dgeneral_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="resize: none;"><?php echo e($adquisicion->descripcion); ?></textarea>
                    </div>
                    <div class="col-4 mt-2">
                        <label for="" class="form-lable">Descripción de la adquisición</label>
                        <textarea name="dadquisicion_1" id="dadquisicion_1" cols="45" rows="5" class="form-control <?php $__errorArgs = ['dadquisicion_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="resize: none;"><?php echo e($adquisicion->descripcionadqui); ?></textarea>
                    </div>
                    <div class="col-4 mt-2">
                        <label for="" class="form-lable">Observaciones<b class="text-danger">*</b></label>
                        <textarea name="observaciones_1" id="observaciones_1" cols="45" rows="5" class="form-control <?php $__errorArgs = ['observaciones_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="resize: none;" required></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 mt-2 ">
                        <label for="" class="form-label">Estaus de adquisición</label>
                        <select name="estatus_adqui" id="estatus_adqui" class="form-select">
                            <option value="1">Seleccionar una opción...</option>
                            <option value="2">Aceptada</option>
                            <option value="0">No aprobada</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mt-2">Actualizar datos</button>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
    </div>
    </div>
</div><?php /**PATH C:\Users\charr\Documents\proyectos\compras\resources\views/adquisiciones/modales/modaleditar.blade.php ENDPATH**/ ?>