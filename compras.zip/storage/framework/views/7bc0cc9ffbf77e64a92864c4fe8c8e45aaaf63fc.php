
<?php $__env->startSection('css'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.bootstrap5.min.css">

    <style>
        .toast-success{
            background-color: #51a351 !important;
        }
        .toast-error{
            background-color: #be5252 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Lista de adquisiciones para almacen</h4>                    
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="container border">
                        <h5 class="text-center mt-2">Adquisiciones
                            <?php if($tipo == 5): ?>
                                en almancen
                            <?php elseif($tipo == 6): ?>
                                entregadas
                            <?php endif; ?>
                        </h5>
                        <table id="example" class="table table-striped dt-responsive nowrap border" style="width:100%;">
                            <thead>
                                <tr>
                                    <th>Fecha Ingreso</th>
                                    <th>Folio</th>
                                    <th>Dependencia</th>
                                    <th>Contenido</th>
                                    <th>Observaciones</th>
                                    <th>Documentación</th>
                                    <th>Estatus</th>
                                    <th>Partida Presupuestal</th>
                                    <th>Descripción General</th>
                                    <th>Clasificación</th>
                                    <th>Unidad de Medida</th>
                                    <th>Desc. Adquisición</th>
                                    <th>Fuentes de Financiamiento</th>
                                    <th>Monto</th>
                                    <th>Proveedor</th>
                                    <th>Fecha de Adjudicación</th>
                                    <th>Fecha Entrega</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $adquisiciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adquisicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr 
                                <?php if(Auth::user()->categoria <> 'admin' && Auth::user()->categoria <> 'cap'): ?>
                                    <?php if($adquisicion->adquisicion_estatus == 2): ?>
                                        style = "color:black;background:#7BCB62;"
                                    <?php elseif($adquisicion->adquisicion_estatus == 1): ?>
                                        style = "color:black;background:#FFFFFF;"
                                    <?php elseif($adquisicion->adquisicion_estatus == 0): ?>
                                        style = "color:black;background:#CB6262;"
                                    <?php endif; ?>  
                                <?php endif; ?>
                                >
                                    <td><?php echo e($adquisicion->fechaadqui); ?></td>
                                    <td><?php echo e($adquisicion->folio); ?></td>
                                    <td><?php echo e($adquisicion->dependencia_nombre); ?></td>
                                    <td>
                                        <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#contenido<?php echo e($adquisicion->idadquisicion); ?>"><i class="fa-regular fa-folder-closed"></i> Contenido</button>
                                    </td>
                                    <td>
                                        <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#observaciones<?php echo e($adquisicion->idadquisicion); ?>"><i class="fa-regular fa-eye"></i> Observaciones</button>
                                    </td>
                                    <td>
                                        <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#documentacion<?php echo e($adquisicion->idadquisicion); ?>"><i class="fa-regular fa-file"></i> Documentos</button>
                                    </td>
                                    <td>
                                        <?php if($adquisicion->adquisicion_estatus == 4): ?>
                                            A LA ESPERA DEL PROVEEDOR
                                        <?php elseif($adquisicion->adquisicion_estatus == 5): ?>
                                            EN EL ALMANCEN
                                        <?php elseif($adquisicion->adquisicion_estatus == 6): ?>
                                            ENTREGADO
                                        <?php else: ?>
                                            ERROR
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($adquisicion->partida ?? 'No se agrego partida presupuestal'); ?></td>
                                    <td><?php echo e($adquisicion->descripcion); ?></td>
                                    <td><?php echo e($adquisicion->clasificacion_nombre); ?></td>
                                    <td><?php echo e($adquisicion->medida_nombre); ?></td>
                                    <td><?php echo e($adquisicion->descripcionadqui); ?></td>
                                    <td><?php echo e($adquisicion->financiamiento_nombre); ?></td>
                                    <td>$<?php echo e(number_format($adquisicion->monto,2, '.', ',')); ?></td>
                                    <td><?php echo e($adquisicion->nombre_comercial ?? 'No hay proveedor'); ?></td>
                                    <td><?php echo e($adquisicion->fechaaprox); ?></td>
                                    <td><?php echo e($adquisicion->fechaentrega); ?></td>
                                    <td>
                                        <?php if(Auth::user()->categoria == 'almacen' && $tipo != 6): ?>
                                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editar<?php echo e($adquisicion->idadquisicion); ?>">Editar</button>    
                                        <?php else: ?>
                                            NO ACCIONES QUE REALIZAR
                                        <?php endif; ?>
                                        
                                    </td>
                                </tr>
                                <?php echo $__env->make('adquisiciones.modales.modaleditaralmacen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('adquisiciones.modales.modalobservaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('adquisiciones.modales.modaldocumentacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('adquisiciones.modales.modalcontenido', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>
    <script>
        $(document).ready(function() {
            toastr.options.timeOut = 8000;
            <?php if(Session::has('error')): ?>
                toastr.error('<?php echo e(Session::get('error')); ?>');
            <?php elseif(Session::has('success')): ?>
                toastr.success('<?php echo e(Session::get('success')); ?>');
            <?php endif; ?>
        });
    </script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/responsive.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                scrollX: true,
                "lengthMenu": [[15,20,50,-1],[15,20,50,"Todos"]],
                language: {
                    "decimal": "",
                    "emptyTable": "No hay información",
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                    "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                    "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "Mostrar _MENU_ Registros",
                    "loadingRecords": "Cargando...",
                    "processing": "Procesando...",
                    "search": "Buscar:",
                    "zeroRecords": "Sin resultados encontrados",
                    "paginate": {
                        "first": "Primero",
                        "last": "Ultimo",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                },
            });
        });
    </script>
    
<?php $__env->stopSection(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\charr\Documents\proyectos\compras\resources\views/adquisiciones/almacen.blade.php ENDPATH**/ ?>