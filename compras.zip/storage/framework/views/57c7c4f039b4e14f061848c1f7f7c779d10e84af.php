<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('meta'); ?>

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link href="<?php echo e(asset('build/assets/app.5380b351.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <!-- Scripts -->
    <!--<?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>-->
</head>
<body>
    <div id="app" class="wrapper">
        <?php echo $__env->make('layouts.menusidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <?php echo $__env->make('layouts.sidehead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main class="py-4">
                <?php if(Auth::user()->user_passestatus == 0): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Recuerde cambiar su contraseña</strong>
                        <p>Este mensaje no desaparecera hasta que haya hecho el cambio de contraseña</p>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if((Auth::user()->categoria == 'admin' || Auth::user()->categoria == 'cap' || Auth::user()->categoria == 'compras') && (Route::currentRouteName() <> 'home' && Route::currentRouteName() <> 'indicemov')  ): ?>
                    <div>
                        <strong class="m-4">Los campos con <b class="text-danger">*</b> son obligatorios</strong>
                    </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
    <?php echo $__env->yieldContent('js'); ?>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    <script src="<?php echo e(asset('build/assets/app.024077bb.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\charr\Documents\proyectos\compras\resources\views/layouts/principal.blade.php ENDPATH**/ ?>