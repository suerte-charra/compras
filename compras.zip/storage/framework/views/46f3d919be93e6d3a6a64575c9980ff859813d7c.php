<!-- Modal -->
<div class="modal fade" id="documentacion<?php echo e($adquisicion->idadquisicion); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="staticBackdropLabel">Documentos referentes a la requisición con folio: <?php echo e($adquisicion->folio); ?></h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-12 row">
                    <div class="col-4 border border-bottom-0 border-end-0">
                        <label for="" class="form-label"><b>Requisición digitalizada</b></label><br>
                        <?php if($adquisicion->documento): ?>
                            <i class="fa-solid fa-eye"></i><a class="btn btn-sm btn-info mb-1" href="<?php echo e(asset('/documentos/documentospresentados/'.$adquisicion->documento)); ?>" target="_blank" style="color:black;"><?php echo e($adquisicion->documento); ?></a>
                        <?php else: ?>
                            <label class="form-label">No tiene documento</label>    
                        <?php endif; ?>
                    </div>
                    <div class="col-4 border border-bottom-0 border-end-0">
                        <label for="" class="form-label"><b>Investigación de mercado</b></label><br>
                        <?php if($adquisicion->investigacion): ?>
                            <a class="btn btn-sm btn-info mb-1" href="<?php echo e(asset('/documentos/investigaciondemercado/'.$adquisicion->investigacion)); ?>" target="_blank" style="color:black;"><?php echo e($adquisicion->investigacion); ?></a>
                        <?php else: ?>
                            <label for="" class="form-label">No tiene investigación de mercado</label>
                        <?php endif; ?>
                    </div>
                    <div class="col-4 border">
                        <label for="" class="form-label" title="Documento que avala si es aceptada o no"><b>Respuesta requisitoria</b></label><br>
                        <?php if($adquisicion->resrequi): ?>
                            <a class="btn btn-sm btn-info mb-1" href="<?php echo e(asset('/documentos/respuestarequisitoria/'.$adquisicion->resrequi)); ?>" target="_blank" style="color:black;"><?php echo e($adquisicion->resrequi); ?></a>
                        <?php else: ?>
                            <label for="" class="form-label">No tiene respuesta requisitoria</label>
                        <?php endif; ?>
                    </div>
                    <div class="col-4 border border-end-0">
                        <label for="" class="form-label"><b>Investigación de referencia</b></label><br>
                        <?php if($adquisicion->adqui_refe): ?>
                            <a class="btn btn-sm btn-info mb-1" href="<?php echo e(asset('/documentos/referencias/'.$adquisicion->adqui_refe)); ?>" target="_blank" style="color:black;"><?php echo e($adquisicion->adqui_refe); ?></a>
                        <?php else: ?>
                            <label for="" class="form-label">No tiene investigación de referencia</label>
                        <?php endif; ?>
                    </div>
                    <div class="col-4 border">
                        <label for="" class="form-label"><b>Suficiencia presupuestal</b></label><br>
                        <?php if($adquisicion->adqui_presupuesto): ?>
                            <a class="btn btn-sm btn-info mb-1" href="<?php echo e(asset('/documentos/presupuestal/'.$adquisicion->adqui_presupuesto)); ?>" target="_blank" style="color:black;"><?php echo e($adquisicion->adqui_presupuesto); ?></a>
                        <?php else: ?>
                            <label for="" class="form-label">No tiene el documento de suficiencia presupuestal</label>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\Users\charr\Documents\proyectos\compras\resources\views/adquisiciones/modales/modaldocumentacion.blade.php ENDPATH**/ ?>