
<?php $__env->startSection('css'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.bootstrap5.min.css">
    <style>
        .toast-success{
            background-color: #51a351 !important;
        }
        .toast-error{
            background-color: #be5252 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Lista de adquisiciones</h4>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label><?php echo e($error); ?></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="container border">
                        <h5 class="text-center mt-2">Adquisiciones 
                            <?php if($tipo == 3): ?>
                                autorizadas
                            <?php elseif($tipo == 2): ?>
                                recepcion aceptada
                            <?php endif; ?>
                        </h5>
                        <table id="example" class="table table-striped dt-responsive nowrap border" style="width:100%;">
                            <thead>
                                <tr>
                                    <th>Fecha Ingreso</th>
                                    <th>Folio</th>
                                    <th>Dependencia</th>
                                    <th>Contenido</th>
                                    <th>Observaciones</th>
                                    <th>Documentación</th>
                                    <th>Partida Presupuestal</th>
                                    <th>Descripción General</th>
                                    <th>Clasificación</th>
                                    <th>Unidad de Medida</th>
                                    <th>Desc. Adquisición</th>
                                    <th>Fuentes de Financiamiento</th>
                                    <th>Monto</th>
                                    <th>Proveedor</th>
                                    <th>Fecha de Adjudicación</th>
                                    <th>Fecha Entrega</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $adquisicionesaprobadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adquisicionesaprobada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr 
                                <?php if(Auth::user()->categoria <> 'admin' && Auth::user()->categoria <> 'cap' && Auth::user()->categoria <> 'compras'): ?>
                                    <?php if($adquisicionesaprobada->adquisicion_estatus == 2): ?>
                                        style = "color:black;background:#7BCB62;"
                                    <?php elseif($adquisicionesaprobada->adquisicion_estatus == 1): ?>
                                        style = "color:black;background:#BACDB4;"
                                    <?php elseif($adquisicionesaprobada->adquisicion_estatus == 0): ?>
                                        style = "color:black;background:#CB6262;"
                                    <?php endif; ?>  
                                <?php endif; ?>
                                >
                                    <td><?php echo e($adquisicionesaprobada->fechaadqui); ?></td>
                                    <td><?php echo e($adquisicionesaprobada->folio); ?></td>
                                    <td><?php echo e($adquisicionesaprobada->dependencia_nombre); ?></td>
                                    <td>
                                        <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#contenido<?php echo e($adquisicionesaprobada->idadquisicion); ?>"><i class="fa-regular fa-folder-closed"></i> Contenido</button>
                                    </td>
                                    <td>
                                        <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#observaciones<?php echo e($adquisicionesaprobada->idadquisicion); ?>"><i class="fa-regular fa-eye"></i> Observaciones</button>
                                    </td>
                                    <td>
                                        <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#documentacion<?php echo e($adquisicionesaprobada->idadquisicion); ?>"><i class="fa-regular fa-file"></i> Documentos</button>
                                    </td>
                                    <td><?php echo e($adquisicionesaprobada->partida ?? 'No se agrego partida presupuestal'); ?></td>
                                    <td><?php echo e($adquisicionesaprobada->descripcion); ?></td>
                                    <td><?php echo e($adquisicionesaprobada->clasificacion_nombre); ?></td>
                                    <td><?php echo e($adquisicionesaprobada->medida_nombre); ?></td>
                                    <td><?php echo e($adquisicionesaprobada->descripcionadqui); ?></td>
                                    <td><?php echo e($adquisicionesaprobada->financiamiento_nombre); ?></td>
                                    <td>$<?php echo e(number_format($adquisicionesaprobada->monto,2, '.', ',')); ?></td>
                                    <td><?php echo e($adquisicionesaprobada->nombre_comercial ?? 'No hay proveedor seleccionado'); ?></td>
                                    <td><?php echo e($adquisicionesaprobada->fechaaprox); ?></td>
                                    <td><?php echo e($adquisicionesaprobada->fechaentrega); ?></td>
                                    <td>
                                        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editar<?php echo e($adquisicionesaprobada->idadquisicion); ?>">Editar</button>
                                    </td>
                                </tr>
                                <?php echo $__env->make('adquisiciones.modales.modalobservacionesaprobadas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('adquisiciones.modales.modaldocumentacionaprobadas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('adquisiciones.modales.modalcontenidoaprobadas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('adquisiciones.modales.modaleditaraprovada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>
    <script>
        $(document).ready(function() {
            toastr.options.timeOut = 8000;
            <?php if(Session::has('error')): ?>
                toastr.error('<?php echo e(Session::get('error')); ?>');
            <?php elseif(Session::has('success')): ?>
                toastr.success('<?php echo e(Session::get('success')); ?>');
            <?php endif; ?>
        });
    </script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/responsive.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                scrollX: true,
                "lengthMenu": [[15,20,50,-1],[15,20,50,"Todos"]],
                language: {
                    "decimal": "",
                    "emptyTable": "No hay información",
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                    "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                    "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "Mostrar _MENU_ Registros",
                    "loadingRecords": "Cargando...",
                    "processing": "Procesando...",
                    "search": "Buscar:",
                    "zeroRecords": "Sin resultados encontrados",
                    "paginate": {
                        "first": "Primero",
                        "last": "Ultimo",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                },
            });
        });
    </script>
    
<?php $__env->stopSection(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\charr\Documents\proyectos\compras\resources\views/adquisiciones/aprobadas.blade.php ENDPATH**/ ?>